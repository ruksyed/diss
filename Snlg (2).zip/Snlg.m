clc;
clear;

%2.1
%Set the signal parameters
Fs = 100;                   % Sampling frequency (Hz)
t = 0:1/Fs:2.2;             % Time vector (s)
f1 = 8;                     % Frequency of sinusoid 1 (Hz)
f2 = 11;                    % Frequency of sinusoid 2 (Hz)
A1 = 0.5;                   % Amplitude of sinusoid 1
A2 = 1;                     % Amplitude of sinusoid 2

% Generate the analogue signal
Sanalog = A1*sin(2*pi*f1*t) + A2*sin(2*pi*f2*t);

% Generate the sampled signal
Ssam = Sanalog(1:100/Fs:end);

% Plot both signals on one graph in time domain
figure;
plot(t, Sanalog, 'b', t(1:length(Ssam)), Ssam, 'ro');
xlabel('Time (s)');
ylabel('Amplitude');
title('Sanalog and Ssam');
legend('Sanalog', 'Ssam');

%2.2

%Load the sampled signal
%Determine the minimum and maximum values of the signal
min_val = min(Ssam);
max_val = max(Ssam);
% Define the quantization step size
quant_step = (max_val - min_val) / 16;
% Define the quantization levels
quant_levels = min_val:quant_step:max_val;
% Quantize the signal using the quantization levels
Squant = zeros(size(Ssam));
for i = 1:numel(Ssam)
    [~, index] = min(abs(quant_levels - Ssam(i)));
    Squant(i) = quant_levels(index);
end
% Plot the quantized signal
t = 0:numel(Ssam)-1;
figure;
plot(t, Ssam, 'b-', t, Squant, 'r-');
xlabel('Time');
ylabel('Amplitude');
title('Ssam and Squant');
legend('Ssam', 'Squant');
% Calculate the signal-to-quantization-noise ratio (SQNR)
noise = Ssam - Squant;
signal_power = mean(Ssam.^2);
noise_power = mean(noise.^2);
SQNR = 10*log10(signal_power/noise_power);
fprintf('SQNR = %.2f dB\n', SQNR);

%2.3
% % Calculate the spectra
N = length(Ssam);
f = Fs*(-N/2:N/2-1)/N; % Frequency vector
Sanalog_spectrum = abs(fftshift(fft(Sanalog))/N);%calculate sanalog spectra
Ssam_spectrum = abs(fftshift(fft(Ssam))/N);%calculate ssam spectra

% Plot the spectra on one graph
figure;
plot(f, Sanalog_spectrum, 'b');
hold on;
plot(f, Ssam_spectrum, 'r');
hold off;
xlim([-20, 20]); % Set the frequency range
ylim([0, max([Sanalog_spectrum, Ssam_spectrum])*1.1]); % Set y-axis limit
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Spectra of Sanalog and Ssam');
legend('Sanalog', 'Ssam');

%Define the analog signal and sample it
% fs = 100;   % Sampling frequency
% t = 0:1/fs:1-1/fs;   % Time vector
% x = cos(2*pi*10*t) + cos(2*pi*20*t);   % Analog signal
% xs = x(1:10:end);   % Sampled signal

% Compute the Fourier transforms of the signals
% X = fft(Sanalog);
% Xs = fft(Ssam);
% 
% % Shift the zero-frequency component to the center of the spectrum
% X = fftshift(X);
% Xs = fftshift(Xs);
% 
% % Create frequency vectors for plotting
% N = length(Sanalog);   % Length of the Fourier transforms
% f = (-N/2:N/2-1)*(Fs/N);   % Frequency vector for analog signal
% fsam = Fs/10;   % Sampling frequency of the sampled signal
% fsam_nyq = fsam/2;   % Nyquist frequency of the sampled signal
% fsam_norm = f/fsam_nyq;   % Normalized frequency vector for sampled signal

% Plot the spectra
% figure;
% subplot(2,1,1);
% plot(f, abs(X));
% title('Spectrum of Analog Signal');
% xlabel('Frequency (Hz)');
% ylabel('Magnitude');
% xlim([-50, 50]);
% 
% subplot(2,1,2);
% plot(fsam_norm, abs(Xs));
% title('Spectrum of Sampled Signal');
% xlabel('Normalized Frequency (\times \pi rad/sample)');
% ylabel('Magnitude');
% xlim([-50, 50]);


%2.4
% Perform ideal low-pass filtering in the frequency domain
f_cutoff = 10; % Cut-off frequency of the ideal low-pass filter
Sanalog_spectrum_filtered = Sanalog_spectrum;
Sanalog_spectrum_filtered(abs(f) > f_cutoff) = 0;

% Generate the reconstructed signal in the time domain
Sreconst = real(ifft(ifftshift(Sanalog_spectrum_filtered*N)));

% Plot the original analogue signal and the reconstructed signal on one graph
figure;
plot(t, Sanalog, 'b', t, Sreconst, 'r');
xlabel('Time (s)');
ylabel('Amplitude');
title('Sanalog and Sreconst');
legend('Sanalog', 'Sreconst');


