clearvars;
close all;
clc;
[y, fs] = audioread('corrupt-sound22.wav');
% sound(y, fs);
t = linspace(0, (size(y,1)/fs), size(y,1));
g=fspecial('gaussian',[1 100],30);
figure;
plot(g);
title('Gaussian Low pass Filter');

med = medfilt1(y,10);
z=conv(med,g);

[yh,yl] = bounds(z);                                                            


figure;
plot(med,'b'); 
hold on;
plot(z,'r','linewidth',2);
legend('Noisy Signal','Signal after noise removal');

smoothedData = smoothdata(z,'movmean','SmoothingFactor',0.25);

% show results
clf
plot(z,'DisplayName','Input data')
hold on
plot(smoothedData,'r','LineWidth',1.5,...
    'DisplayName','Smoothed data')
hold off
legend

%sound(smoothedData, fs);

audiowrite('processedgaussiansmooth.wav',z,fs);
sound(z*10,fs);

