clearvars;
close all;
clc;

[y, fs] = audioread('corrupt-sound22.wav');
% sound(y, fs);
t = linspace(0, (size(y,1)/fs), size(y,1));
% plot(t,y);


a = medfilt1(y,10);
b = wiener2(a);

plot(t, a, t, b);
legend('Original','Filtered')
legend('boxoff')

audiowrite('processedWeiner.wav',b,fs);
[x, fs] = audioread('processedWeiner.wav');
sound(x, fs);
