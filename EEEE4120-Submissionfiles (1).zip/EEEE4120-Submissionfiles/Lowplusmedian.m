clearvars;
close all;
clc;
[y, fs] = audioread('corrupt-sound22.wav');
[pxx, fx] = pwelch (y,[],[],[],fs);
plot(fx,10*log10(abs(pxx)))
N = 20;
fs = 16000;
Fp = 1000; 
%sound(y, fs);
t = linspace(0, (size(y,1)/fs), size(y,1));

p = designfilt('lowpassfir','FilterOrder',20,'CutoffFrequency',1000,'DesignMethod','window','Window',{@kaiser,3},'SampleRate',fs);
z = filter(p,y);
plot(t,y)
hold on
plot(t,z)
xlabel('Time (s)')
ylabel('Amplitude')
legend('Original Signal','Filtered Data')


a = medfilt1(z,10);
smoothedData = smoothdata(a,'movmean','SmoothingFactor',0.25);

% show results
clf
plot(a,'DisplayName','Input data')
hold on
plot(smoothedData,'r','LineWidth',1.5,...
    'DisplayName','Smoothed data')
hold off
legend

audiowrite('processedLowmedian.wav',smoothedData,fs);
[x, fs] = audioread('processedLowmedian.wav');
sound(x, fs);



