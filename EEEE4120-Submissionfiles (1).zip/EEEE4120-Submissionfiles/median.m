clearvars;
close all;
clc;

[y, fs] = audioread('corrupt-sound22.wav');
% sound(y, fs);
t = linspace(0, (size(y,1)/fs), size(y,1));
% plot(t,y);

a = medfilt1(y,10);
plot(t, y, t, a);
legend('Original','Filtered')
legend('boxoff')

audiowrite('processed.wav',a,fs);
[x, fs] = audioread('processed.wav');
sound(x, fs);











