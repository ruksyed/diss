clc;
clear; 

%PART A

load Lena.mat;
region_start_row = 100;
region_start_col = 200;
small_region = Lena(region_start_row:region_start_row+7, region_start_col:region_start_col+7); % Select an 8x8 region for the row and column

figure;
imshow(small_region); % Display the small region
title('small region');
colormap(gray(256));  % Set the colormap to 256 shades of gray
fprintf('8x8 Pixel Region:\n');
disp(small_region);

dct_result = dct2(small_region); % Apply 2D DCT to the small region

fprintf('8x8 DCT Coefficients:\n');
disp(dct_result);

idct_result = idct2(dct_result); % Apply 2D inverse DCT to the DCT coefficients
fprintf('8x8 Inverse DCT:\n');
disp(idct_result);

%PART B

% Assuming the small_region variable from the previous code
dct_result = dct2(small_region);

load M.mat;
quantized_dct = round(dct_result ./ M);% Quantize the DCT coefficients

dequantized_dct = quantized_dct .* M; % Dequantize the quantized DCT coefficients
restored_pixels = idct2(dequantized_dct); % Apply 2D inverse DCT to the dequantized DCT coefficients

fprintf('Original 8x8 Pixel Values:\n');
disp(small_region);
fprintf('Restored 8x8 Pixel Values:\n');
disp(restored_pixels);

%PART C
dct_fun = @(block_struct) dct2(block_struct.data);
dct_image = blockproc(Lena, [8 8], dct_fun); %Apply 2D DCT to the entire Lena image using 8x8 blocks

quant_fun = @(block_struct) round(block_struct.data ./ M);% function to quantize DCT coefficients
quantized_dct_image = blockproc(dct_image, [8 8], quant_fun);% Quantize the DCT coefficients for the entire image

dequant_fun = @(block_struct) block_struct.data .* M;%function to dequantize DCT coefficients
dequantized_dct_image = blockproc(quantized_dct_image, [8 8], dequant_fun);

idct_fun = @(block_struct) idct2(block_struct.data);%apply 2D inverse DCT to an image block
restored_image = blockproc(dequantized_dct_image, [8 8], idct_fun);% Apply 2D inverse DCT to the entire image using 8x8 blocks

figure;
imshow(Lena);
title('Original Image');
figure;
imshow(restored_image, [0 255]); % Display the restored Lena image with a specified display range
title('Restored Image');

mse = mean((double(Lena(:)) - double(restored_image(:))).^2);% Calculate the mean squared error between the original and restored images
psnr = 10 * log10(255^2 / mse); % Calculate the PSNR (peak signal-to-noise ratio) in dB
original_data = numel(Lena) * 8; % Calculate the number of bits in the original image with 8 bits per pixel
compressed_data = sum(sum(arrayfun(@(x) ceil(log2(abs(x)+1)), quantized_dct_image)));
compression_ratio = original_data / compressed_data;

scale_factors = 0.5:0.5:4; %range of scale factors for the quantization matrix M
psnrs = zeros(size(scale_factors)); % Initializing an array to store PSNR values
compression_ratios = zeros(size(scale_factors));% Initializing an array to store compression ratios

for i = 1:numel(scale_factors)
    M_scaled = M * scale_factors(i); % Scale the quantization matrix M by the current scale factor
    quantized_dct_image = blockproc(dct_image, [8 8], @(block_struct) round(block_struct.data ./ M_scaled));
    dequantized_dct_image = blockproc(quantized_dct_image, [8 8], @(block_struct) block_struct.data .* M_scaled);
    restored_image = blockproc(dequantized_dct_image, [8 8], idct_fun);

    mse = mean((double(Lena(:)) - double(restored_image(:))).^2);
    psnrs(i) = 10 * log10(255^2 / mse);
    % Calculate the histogram of the quantized DCT coefficients
[counts, ~] = histcounts(quantized_dct_image(:), 'BinMethod', 'integers');

% Calculate the probabilities of the quantized DCT coefficients
probabilities = counts / sum(counts);

% Calculate the entropy of the quantized DCT coefficients
entropy = -sum(probabilities .* log2(probabilities + eps));

% Calculate the number of bits in the compressed data using entropy
compressed_data = numel(quantized_dct_image) * entropy;
    compression_ratios(i) = original_data / compressed_data;
end

figure;
plot(compression_ratios, psnrs, 'o-');
xlabel('Compression Ratio');
ylabel('PSNR (dB)');
title('Image Quality vs Compression');




