clc
clearvars;
close all;
workspace;  % Make sure the workspace panel is showing.

cl =imread('raw2-image22.png'); 
b=rgb2gray(cl);
figure;
imshow(b);  % Display the original image.
title('Image with shot and periodic noise');

% Apply a median filter to the image to remove shot noise
c = medfilt2(b);
figure;
imshow(c);
title('Image without shot noise');

% Compute the FFT of the noisy image.
af=fft2(c);

% Shift the FFT so that the DC component is in the center.
af1=fftshift(af);

% Display the FFT of the noisy image.
figure;
imshow(mat2gray(log(1+abs(af1))));
title('SHIFTED FFT of the input image');
impixelinfo

% Apply a low-pass filter to the shifted FFT.
% This removes high-frequency components in the noise.
% The size of the filter and the cutoff frequency depends on the
% characteristics of the noise in the image.
filter = ones(size(af1));  % Create a filter of the same size as the FFT.

% Set the values of the filter to zero outside of a circular region centered
% at the middle of the image. This will act as a low-pass filter, letting
% through only the low-frequency components.
center = size(af1) / 2;  % Find the center of the filter.
radius = 100;  % Set the radius of the low-pass filter.

% Nested for loop to set the values of the filter to zero outside of the
% circular region.
for i = 1:size(filter, 1)
    for j = 1:size(filter, 2)
        if (i - center(1))^2 + (j - center(2))^2 > radius^2
            filter(i, j) = 0;
        end
    end
end

% Apply the low-pass filter to the shifted FFT.
filtered_fft = af1 .* filter;

% Shift the FFT back to its original position.
filtered_fft = ifftshift(filtered_fft);

% Compute the inverse FFT of the filtered FFT. This will give us the denoised
% image.
aa = ifft2(filtered_fft);

% Display the denoised image.
figure;
imshow(uint8(aa));
title('Denoised Image');

imwrite(aa,'process2.png');

