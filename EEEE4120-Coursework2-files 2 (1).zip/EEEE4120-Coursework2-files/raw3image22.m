clc
clearvars;
close all;
% image_info = imfinfo('clean-image22.png');
% disp(image_info)


img = imread('raw3-image22.png');

% Convert the image to the Lab
cform = makecform('srgb2lab');
lab_img = applycform(img, cform);

% Split the image into its L, a, and b components
L = lab_img(:,:,1);
a = lab_img(:,:,2);
b = lab_img(:,:,3);

% Shift the a and b channels to correct for chromatic aberration
a_corrected = imtranslate(a, [0.1, 0.1]);
b_corrected = imtranslate(b, [-0.1, -0.1]);

% Combine the corrected channels into a single image
lab_img_corrected = cat(3, L, a_corrected, b_corrected);

% Convert the image back to the RGB color space
cform = makecform('lab2srgb');
img_corrected = applycform(lab_img_corrected, cform);

figure;
imshow(img);
title('Original Image');

figure;
imshow(img_corrected);
title('Corrected Image');

imwrite(img_corrected,'process3.png');

