clc
clearvars;
close all;
warning off;

cl =imread('raw1-image22.png'); 
figure;
imshow(cl);  % Display the original image.
title('Image with Salt & Pepper Noise');


% Median Filter the image:
% Get rid of the noise by replacing with median.
I_filtered=medfilt3(cl,[5,5,3]); 
figure;
imshow(I_filtered);
title('After Median FIltering Image');

% This imlocalbrighten improves the intensity of the image, with a brightness value of 0.4.  
[B] = imlocalbrighten(I_filtered,0.4); 
figure;
imshow(B);
title('Better light intensity image');

imwrite(B,'process1.png');